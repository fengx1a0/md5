import hashlib

md5 = hashlib.md5("".encode())
with open("md5_2.py","rb") as f:
    while True:
        temp = f.read(1)
        if temp:
            md5.update(temp)
        else:
            break
print(md5.hexdigest())