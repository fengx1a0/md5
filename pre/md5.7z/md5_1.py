import hashlib
md5 = hashlib.md5("".encode())
file = open("md5_1.py", "rb")
md5.update(file.read())
 
print(md5.hexdigest())